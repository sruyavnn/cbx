import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-topdlistview',
  templateUrl: './topdlistview.component.html',
  styleUrls: ['./topdlistview.component.css']
})
export class TopdlistviewComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
