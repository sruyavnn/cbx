import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-topdgridview',
  templateUrl: './topdgridview.component.html',
  styleUrls: ['./topdgridview.component.css']
})
export class TopdgridviewComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
