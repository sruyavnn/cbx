export class Searchparams{
   public sortBy: string;
   public gridList: string="gridView";
   public searchKeyword: string="";
   public after:string="0";
   public limit:string="10";
   public totalhitcount:string="0";
   public totalhitcountChild:string="0";
   // public search:boolean=false;
   // public paging:boolean=true;

}