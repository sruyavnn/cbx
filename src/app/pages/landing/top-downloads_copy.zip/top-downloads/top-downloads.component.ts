import { SharedService } from 'src/app/services/shared.service';
import {ListViewService} from '../../../services/listview.service';
import { Component, OnInit, HostListener, ViewEncapsulation } from '@angular/core';
import { AfterViewInit, ElementRef, ViewChild } from '@angular/core';

import { DataService } from 'src/app/services/data.service';
import { Router, ActivatedRoute } from '@angular/router';
import { HttpParams } from '@angular/common/http';
import { Searchparams } from 'src/app/models/searchparams';
import { NgxSpinnerService } from 'ngx-spinner';
declare var $: any;

@Component({
  selector: 'app-top-downloads',
  templateUrl: './top-downloads.component.html',
  styleUrls: ['./top-downloads.component.css']
})
export class TopDownloadsComponent implements OnInit {
  trtopDownloadData: any;
  selectAll:boolean;
  assetId: string;
  allValues: string[] = [];
  selectedValues: string[] = [];
  constructor(private _sharedservice: SharedService, private listViewService: ListViewService, private spinner: NgxSpinnerService, ) {

  }
  searchParameters =new Searchparams();
  topDownloadData: any;
  selectedRows: ItopDownload[];
  items: any;
  btnEnableDisable: boolean =  true;
 PageLimit:string="10";
  PageAfter:string="0";
  page:number=1;
  paginationFlag:boolean;

  ngOnInit() {
    this.getTopDownloadsData();
    //this.topDownladgrouping();
    // $(".topd-table tr").click(function () {


    // });

  }

  getTopDownloadsData() {
    console.log('cars');
 this.assetId='c7c0b34a5fa903aacec8a0b5525cf6b8d9a016f5';
var serviceUrl='/otmmapi/v5/folders/'+this.assetId+'/children/?load_type=metadata&load_multilingual_values=true&level_of_detail=slim&after='+this.PageAfter+'&limit='+this.PageLimit+'&preference_id=ARTESIA.PREFERENCE.GALLERYVIEW.DISPLAYED_FIELDS&sort=asc_NAME'
    this._sharedservice.getService(serviceUrl
    ).subscribe(data => {
      console.log('in cars');
      if (window.location.host.split(':')[0] == "localhost") {
        var topdData = data.folder_children.asset_list.filter(fl => fl.data_type != "undefined");
        for (var i = 0; i < topdData.length; i++) {
          topdData[i].rendition_content.preview_content.url = "https://cdam-dev.cisco.com" + topdData[i].rendition_content.preview_content.url;
          topdData[i].isSelected=false;
        
        }
        this.topDownloadData = topdData;

        //this.fourTtopDownloadData = this.chunkArray(4);
      }
      else {
        var topdData  = data.folder_children.asset_list.filter(fl => fl.data_type != "undefined");
        for (var i = 0; i < topdData.length; i++) {
          //topdData[i].rendition_content.preview_content.url = "https://cdam-dev.cisco.com" + topdData[i].rendition_content.preview_content.url;
          topdData[i].isSelected=false;
        
        }
        this.topDownloadData = topdData;
        // this.fourTtopDownloadData = this.chunkArray(4);
      }
      console.log(this.topDownloadData);
   //if(this.topDownloadData.length>10)
      this.paginationFlag
    });
  }


  //onclick func in topdownloads
  topDownloadsData(name) {
    $('#' + name.asset_id).addClass("selected").siblings().removeClass("selected");
    this.listViewService.trRightPanel(name);
  }





  checkAll: boolean;
  checkUnAll() {
    if (this.checkAll) {
      this.btnEnableDisable = false;
    }
    else {
      this.btnEnableDisable = true;
    }
    for (var i = 0; i < this.topDownloadData.length; i++) {
      if (this.checkAll) {
        this.topDownloadData[i].isSelected = true;
      }
      else {
        this.topDownloadData[i].isSelected = false;

      }
    }
  }

  mutltiAssetDownloads() {
    for (let i = 0; i < this.topDownloadData.length; i++) {
      if (this.topDownloadData[i].isSelected) {
        var iframe = $('<iframe style="visibility: collapse;"></iframe>');
        $('body').append(iframe);
        var content = iframe[0].contentDocument;
        var url = '/otmmapi/v5/renditions/' + this.topDownloadData[i].rendition_content.preview_content.id;

        var form = '<form action="' + url + '" method="GET"><input type="hidden" name="disposition" value="attachment" /></form>';
        content.write(form);
        $('form', content).submit();
        setTimeout((function (iframe) {
          return function () {
            iframe.remove();
          }
        })(iframe), 2000);

      }
    }
  }

  oneSelected(data) {
    if (data.isSelected) {
      this.topDownloadData.filter(x => x.asset_id == data.asset_id)[0].isSelected = false;
    }
    else {
      this.topDownloadData.filter(x => x.asset_id == data.asset_id)[0].isSelected = true;
    }
    if (this.topDownloadData.filter(x => x.isSelected).length == this.topDownloadData.length) {
      this.checkAll = true;
    }
    else {
      this.checkAll = false;
    }
    if (this.topDownloadData.filter(x => x.isSelected).length > 0) {
      this.btnEnableDisable = true;
    }
    else {
      this.btnEnableDisable = false;
    }
  }

  checkUncheckAll() {
    for (var i = 0; i < this.topDownloadData.length; i++) {
      if (this.selectAll) {
        this.btnEnableDisable = false;
        this.topDownloadData[i].isSelected = true;
      }
      else {
        this.btnEnableDisable = true;
        this.topDownloadData[i].isSelected = false;
      }
    }
  }
  checkUncheckSingle(flag, asset_id) {
    
    var selectedLength = this.topDownloadData.filter(x => x.isSelected == true).length;
    if(selectedLength>0){
      this.btnEnableDisable = false;
    }
    else{
      this.btnEnableDisable = true;
    }
    if (selectedLength == this.topDownloadData.length) {
      this.selectAll = true;
    }
    else {
      this.selectAll = false;
    }

  }

  searchKeyword:string="";
  getSearchData() {
    this.spinner.show();
    let params = new HttpParams()
    .set('keyword_query', '('+this.searchKeyword+')')
    .set('load_type', 'metadata')
    .set('load_multilingual_values', 'true')
    .set('level_of_detail', 'slim')
    .set('multilingual_language_code', 'en_US')
    .set('folder_filter_type', 'all')
    .set('folder_filter', this.assetId)
    .set('search_config_id', '3')
    .set('keyword_scope_id', '3')
    .set('preference_id', 'ARTESIA.PREFERENCE.GALLERYVIEW.DISPLAYED_FIELDS' )
    .set('after', this.PageAfter)
    .set('limit',  this.PageLimit);
    var url = "/otmmapi/v5/search/text";
    this._sharedservice.postService(url, params).subscribe(result => {
      console.log('AssetList', result);  
      //this.searchParameters.totalhitcount=result.search_result_resource.search_result.total_hit_count;
      this.topDownloadData=result.search_result_resource.asset_list;
  
      // if(this.topDownloadData.length>0)
      // this.listViewService.listviewsortbtn(true);
      // else
      // this.listViewService.listviewsortbtn(false);
  
  
      this.spinner.hide();
    },
    (err: any) => {
      this.spinner.hide();
  
    }
    );
  }
  paginateNext(){
      this.PageAfter=String(this.page*10);
    this.page=this.page-1;
      this.getSearchData();
  }
  paginatePrev(){
    this.page=this.page-1;
    this.PageAfter=String(this.page*10);
    this.getSearchData();
}
}
export interface ItopDownload {
  asset_id?;
  name?;

}


